# Captura inicial, 2026-09-30

Original en curso: `/home/desdelinux/kraken-v4-capture/01-arranque-20260930-211430-y67Orb/traffic.pcap`.
Bus 3 completo: contiene otros dispositivos y audio. No publicar original sin filtrar.
`initial-snapshot.pcap` es una copia temporal de análisis que se va actualizando.

## Cronología

- Inicio: dongle 1532:056c, dirección 29.
- El usuario confirmó que cambió físicamente a cable USB durante la captura.
  Aparece 1532:056b, dirección 30, puerto 3-4. NO es una conmutación de protocolo
  causada por Synapse; no sacar esa conclusión de la secuencia.
- Usuario volvió al dongle inalámbrico: 1532:056c, dirección 32, puerto 3-3.
- Libvirt tenía un hostdev marcado missing=yes. Se retiró esa asignación y se
  volvió a asignar el dongle con --live (sin sudo, grupo libvirt).
- ~21:23 Windows detectó Razer Kraken V4 Chat/Game. Synapse inició instalación
  automática del módulo de soporte de 93 MB. No se seleccionó firmware updater.

## Primeras transacciones candidatas (NO validadas aún como batería)

Tramas del original y del snapshot, dirección 32:

- 5451: SET_REPORT, bmRequestType 0x21, bRequest 0x09, wValue 0x0202,
  wIndex 5, wLength 64. Report Output 02, no Feature.
  Payload exacto:
  `0200600000000400008021000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c700`
- 5452: finalización USB exitosa de 5451.
- 5453: interrupt IN endpoint 0x84, 64 bytes:
  `02026000000005008080210101450000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000300`
  Byte offset 13 = 0x45 = 69. Hipótesis de porcentaje; todavía no contrastada con UI.
- 5447: misma estructura de solicitud, opcode 2a, penúltimo byte cc.
  Respuesta 5449: opcode 2a, byte 13 cero. Hipótesis de estado de carga,
  todavía NO validada mediante transición física.
- También hay mensajes IN prefijo 02 0a 60 con opcode 21 y valores variables.
  No tratarlos como respuestas síncronas sin distinguirlos del prefijo 02 02 60.

Estas transacciones se observaron realmente en el dispositivo objetivo. No se
ha reproducido ninguna desde Linux. Falta porcentaje UI, estabilidad, otras cargas,
desconexión y validación de semántica antes de implementar.

## Correlación UI confirmada, 21:29

Tras reiniciar Windows y abrir Synapse: **44 %** en panel y página Kraken V4.
Evidencia visual: `synapse-44-percent.png`.
Respuestas síncronas prefijo `02026000000005008080210101`, byte 13 `2c` (=44):
tramas 7679 (21:29:13.643), 7855, 7883, 7961, 8001 (21:29:18.683).
Esto confirma la correlación de la consulta 21 con batería a este nivel.
Falta aún segunda carga, transición de carga y replay en Linux.
Las notificaciones previas 020a60…21… contienen valores descendentes 53→47,
pero no hubo UI visible entonces; no contarlas como validación de varios niveles.

## Lectura de archivos con tshark en este entorno

## Transición a carga, 21:34

Usuario confirmó cargador externo, manteniendo dongle inalámbrico.
UI mantiene 44 % y añade rayo de carga; `synapse-44-charging.png`.
Tramas 21609 (21:34:11.375537) y 21611 (21:34:11.383547):
prefijos `020a604e0000050080802a020101` y `020a604f0000050080802a020101`.
Notificaciones opcode 2a con byte 13 = 1; previamente respuestas síncronas
2a tenían byte 13 = 0 sin cargar. Aún falta respuesta síncrona durante carga
y transición inversa. Snapshot: `charging-snapshot.pcap`, actualizado durante análisis.

## Detalles de herramientas

Tshark dio Permission denied al abrir tanto el original como la copia del proyecto,
incluso fuera del sandbox. Python puede leer ambos. Se pudo analizar pasando stdin:

```bash
cat kraken-v4-research/initial-snapshot.pcap | tshark -r - \
  -Y 'usb.device_address == 32' -T fields -e frame.number -e _ws.col.Info
```

No se cambió ningún permiso del sistema. Para OUT SET_REPORT, el payload aparece
como Data Fragment dentro de Setup Data; para interrupt IN como `usbhid.data`.
